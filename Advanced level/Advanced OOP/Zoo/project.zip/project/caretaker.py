from project.employee_base import EmployeeBase


class Caretaker(EmployeeBase):
    pass