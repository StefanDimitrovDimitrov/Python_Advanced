from project.animal_base import AnimalBase

class Lion(AnimalBase):
    needs = 50

