from project.animal_base import AnimalBase

class Tiger(AnimalBase):
    needs = 45