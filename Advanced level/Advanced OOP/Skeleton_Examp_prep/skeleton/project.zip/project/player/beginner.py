from project.player.player import Player


class Beginner(Player):

    def __init__(self, username, health: int):
        self.health = 50
        super().__init__(username, health)
