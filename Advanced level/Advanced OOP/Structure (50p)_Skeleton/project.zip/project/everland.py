class Everland:
    def __init__(self):
        self.rooms = []

    def aff_room(self,room):
        pass

    def def_monthly_consumptions(self):
        pass

    def pay(self):
        pass

    def status(self):
        pass
