album = ["1"]

if album:
    print(2)
else:
    print(5)